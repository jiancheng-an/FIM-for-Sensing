function [y,yy]=myfun_withgrad(ThetaK,PhiK,AZX,Rx,K,d,k_c,Nt)
for i = 1:K
    aVectorY = exp(-1i*k_c*sind(ThetaK(i))*sind(PhiK(i))*d);
    A(:,i) = AZX(:,i).*aVectorY;
end
BB=A*A';
y=-real(trace(Rx*BB));
if nargout>1
    yy=calculate_grad(ThetaK,PhiK,AZX,Rx,K,d,k_c,Nt);
 end
end