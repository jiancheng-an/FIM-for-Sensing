function yy=calculate_grad(ThetaK,PhiK,AZX,Rx,K,d,k_c,Nt)
s_Theta=sind(ThetaK);
s_Phi=sind(PhiK);
for i = 1:K
    aVectorY = exp(-1i*k_c*sind(ThetaK(i))*sind(PhiK(i))*d);
    A(:,i) = AZX(:,i).*aVectorY;
end
for n=1:Nt
    parA_d=-1j*k_c*[zeros(n-1,K);A(n,:);zeros(Nt-n,K)]*diag(s_Theta.*s_Phi);
    CC=parA_d*A'+A*parA_d';
    yy(n,1)=-real(trace(Rx*CC));
end