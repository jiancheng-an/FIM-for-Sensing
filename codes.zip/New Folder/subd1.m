function     delta_d=subd1(ThetaK,PhiK,AZX,Rx,K,k_c,delta_d0,dtmax,Nt)
tic
% ------------trust-region-reflective Algorithm---------------------------
options = optimoptions('fmincon','Algorithm','trust-region-reflective','SpecifyObjectiveGradient',true);
lb = -dtmax*ones(Nt,1);
ub = dtmax*ones(Nt,1);
[delta_d,~]=fmincon(@(d)myfun_withgrad(ThetaK,PhiK,AZX,Rx,K,d,k_c,Nt),delta_d0,[],[],[],[],lb,ub,[],options);
%---------------------gradient descent Algorithm---------------------------
% delta_d=mymin_grad(ThetaK,PhiK,AZX,Rx,K,delta_d0,k_c,dtmax,Nt); 
toc