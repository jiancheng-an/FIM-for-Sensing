function delta_d=mymin_grad(ThetaK,PhiK,AZX,Rx,K,delta_d0,k_c,dtmax,Nt)
tic
kes=1e-2;%kes[1e-3,0.3]
kappa=0.75;%shrink [0.1,0.8]
f0=myfun(ThetaK,PhiK,AZX,Rx,K,delta_d0,k_c);
gamma=1e-5;
for kk=1:1000
    grad=calculate_grad(ThetaK,PhiK,AZX,Rx,K,delta_d0,k_c,Nt);% gradient calculation
    delta_d0=delta_d0-gamma*grad;% gradient descent
    delta_d0=sign(delta_d0).*min(abs(delta_d0),dtmax);
    f1=myfun(ThetaK,PhiK,AZX,Rx,K,delta_d0,k_c);
    if f1>f0-kes*gamma*abs(-grad.'*grad)%armijo condition
        gamma=kappa*gamma;
    end
    f0=f1;
    if max(abs(grad))<1e-6
        break
    end
end
toc
delta_d=delta_d0;
