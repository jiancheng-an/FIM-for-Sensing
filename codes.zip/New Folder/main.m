clc;clear;
close all;

Nt1 = 10;
Nt2 =10;
Nt = Nt1*Nt2;% antenna number


c=3e8;%speed of light
f=28e9;
lambda=c/f;% wavelength
k_c=2*pi/lambda;
dxt=0.5*lambda;
dzt=0.5*lambda;
delta_dt=zeros(Nt,1);
dtmax=lambda;%maximum morphing range

K=3;
ThetaK=[30,30,135];
PhiK=[60,120,90];% target locations
a_dx=kron(ones(Nt2,1),(0:Nt1-1).');
a_dz=kron((0:Nt2-1).',ones(Nt1,1));



for i = 1:K
    aVectorY = exp(-1i*k_c*sind(ThetaK(i))*sind(PhiK(i))*delta_dt);
    aVectorX = exp(-1i*k_c*dxt*sind(ThetaK(i))*cosd(PhiK(i))*(0:Nt1-1)');
    aVectorZ = exp(-1i*k_c*dzt*cosd(ThetaK(i))*(0:Nt2-1)');
    AZX(:,i)=kron(aVectorZ,aVectorX);
    A(:,i) = AZX(:,i).*aVectorY;
end

BB=A*A';


P=10.^(10/10)*10^-3; %transmit power

Kmax=50;
delta_dt=zeros(Nt,1);
for kk=1:Kmax
    cvx_begin sdp quiet
    variable Rx(Nt,Nt) hermitian
    minimize -trace(Rx*BB)
    subject to
    Rx>=0
    diag(Rx)==P/Nt
    cvx_end
    delta_dt=subd1(ThetaK,PhiK,AZX,Rx,K,k_c,delta_dt,dtmax,Nt);%surface shape optimization
    for i = 1:K
        aVectorY = exp(-1i*k_c*sind(ThetaK(i))*sind(PhiK(i))*delta_dt);
        A(:,i) = AZX(:,i).*aVectorY;
    end
    BB=A*A';
end



% ----------------------------beampattern----------------------------------
Theta_scan = 0:1:180;
Phi_scan = 0:1:180;
Theta_Length = length(Theta_scan);
Phi_Length = length(Phi_scan);


i=1;
for i_Theta = 1:Theta_Length
    for i_Phi = 1:Phi_Length
        theta = Theta_scan(i_Theta);
        phi = Phi_scan(i_Phi);
        aVectorY = exp(-1i*k_c*sind(theta)*sind(phi)*delta_dt);
        aVectorX = exp(-1i*k_c*dxt*sind(theta)*cosd(phi)*(0:Nt1-1)');
        aVectorZ = exp(-1i*k_c*dzt*cosd(theta)*(0:Nt2-1)');
        a = kron(aVectorZ,aVectorX).*aVectorY;
        G(i)=a'*Rx*a;
        i=i+1;
    end
end


GG=reshape(G.',Phi_Length,Theta_Length);

GdB=10*log10(abs(GG))+30;%power to dBm 

[X,Y]=meshgrid(Theta_scan,Phi_scan);
mesh(X,Y,GdB);
xlabel('\theta');ylabel('\phi');zlabel('BeamPattern (dBm)');
caxis([-20 40])






