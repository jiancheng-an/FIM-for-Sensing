function y=myfun(ThetaK,PhiK,AZX,Rx,K,d,k_c)
for i = 1:K
    aVectorY = exp(-1i*k_c*sind(ThetaK(i))*sind(PhiK(i))*d);
    A(:,i) = AZX(:,i).*aVectorY;
end
BB=A*A';
y=-real(trace(Rx*BB));
end